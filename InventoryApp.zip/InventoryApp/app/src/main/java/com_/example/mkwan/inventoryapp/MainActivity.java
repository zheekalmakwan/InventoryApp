package com_.example.mkwan.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.CONTENT_URI;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.PRICE;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.PRODUCT_IMAGE;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.PRODUCT_NAME;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.QUANTITY;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.SUPPLIER_NAME;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.SUPPLIER_PHONE_NUMBER;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory._ID;

public class MainActivity extends AppCompatActivity {

    InventoryDbHelper inventoryDbHelper;
    ListView listView;
    TextView noDataTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inventoryDbHelper = new InventoryDbHelper(this);
        listView = findViewById(R.id.list_item_data);
        noDataTextView = findViewById(R.id.no_data_tv);
        LoaderManager loaderManager = getSupportLoaderManager();
        loaderManager.initLoader(0, null, cursorLoader);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu_style, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_item:
                Intent addIntent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(addIntent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public Cursor ReadData() {
        String[] columns = {_ID, PRODUCT_IMAGE,
                PRODUCT_NAME, PRICE,
                QUANTITY, SUPPLIER_NAME,
                SUPPLIER_PHONE_NUMBER};
        Cursor cursor = getContentResolver().query(CONTENT_URI, columns, null, null, null);
        if (cursor.getCount() > 0) {
            listView.setVisibility(View.VISIBLE);
            noDataTextView.setVisibility(View.GONE);
        } else {
            listView.setVisibility(View.INVISIBLE);
            noDataTextView.setVisibility(View.VISIBLE);
            noDataTextView.setText("No data is inserted");
        }
        return cursor;
    }

    @Override
    protected void onStart() {
        LoaderManager loaderManager = getSupportLoaderManager();
        loaderManager.initLoader(0, null, cursorLoader);
        super.onStart();
    }

    LoaderManager.LoaderCallbacks<Cursor> cursorLoader = new LoaderManager.LoaderCallbacks<Cursor>() {
        @NonNull
        @Override
        public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {

            String[] columns = {
                    PRODUCT_NAME,
                    PRICE,
                    QUANTITY,
                    SUPPLIER_NAME,
                    SUPPLIER_PHONE_NUMBER};

            return new CursorLoader(
                    MainActivity.this,
                    CONTENT_URI,
                    columns,
                    null,
                    null,
                    null);
        }

        @Override
        public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
            InventoryCursorAdapter adapter = new InventoryCursorAdapter(MainActivity.this, ReadData());
            listView.setAdapter(adapter);
            adapter.changeCursor(ReadData());

        }

        @Override
        public void onLoaderReset(@NonNull Loader<Cursor> loader) {

        }
    };

    @Override
    protected void onDestroy() {
        inventoryDbHelper.close();
        super.onDestroy();
    }
}
