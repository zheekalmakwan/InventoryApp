package com_.example.mkwan.inventoryapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import static android.provider.BaseColumns._ID;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.CONTENT_URI;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.PRICE;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.PRODUCT_NAME;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.QUANTITY;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.SUPPLIER_NAME;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.SUPPLIER_PHONE_NUMBER;

public class EditActivity extends AppCompatActivity {

    EditText editProductName;
    EditText editPrice;
    EditText editQuantity;
    ImageView editIncrease;
    ImageView editDecrease;
    EditText editSupplierName;
    EditText editSupplierPhoneNumber;
    Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        int id = Integer.parseInt(getIntent().getStringExtra(_ID));
        uri = Uri.withAppendedPath(CONTENT_URI, id + "");
        String columns[] = {
                _ID,
                PRODUCT_NAME,
                PRICE,
                QUANTITY,
                SUPPLIER_NAME,
                SUPPLIER_PHONE_NUMBER};
        editProductName = findViewById(R.id.edit_product_name_tv);
        editPrice = findViewById(R.id.edit_price_tv);
        editQuantity = findViewById(R.id.edit_quantity_tv);
        editIncrease = findViewById(R.id.edit_increase);
        editDecrease = findViewById(R.id.edit_decrease);
        editSupplierName = findViewById(R.id.edit_supplier_name_tv);
        editSupplierPhoneNumber = findViewById(R.id.edit_supplier_phone_number_tv);


        Cursor cursor = getContentResolver().query(uri, columns, null, null, null);
        try {
            while (cursor.moveToNext()) {
                int productNameIndex = cursor.getColumnIndexOrThrow(PRODUCT_NAME);
                int priceIndex = cursor.getColumnIndexOrThrow(PRICE);
                int quantityIndex = cursor.getColumnIndexOrThrow(QUANTITY);
                int supplierNameIndex = cursor.getColumnIndexOrThrow(SUPPLIER_NAME);
                int supplierPhoneNumberIndex = cursor.getColumnIndexOrThrow(SUPPLIER_PHONE_NUMBER);

                String productName = cursor.getString(productNameIndex);
                int price = cursor.getInt(priceIndex);
                int quantity = cursor.getInt(quantityIndex);
                String supplierName = cursor.getString(supplierNameIndex);
                String supplierPhoneNumber = cursor.getString(supplierPhoneNumberIndex);
                editProductName.setText(productName);
                editPrice.setText(String.valueOf(price));
                editQuantity.setText(String.valueOf(quantity));
                editSupplierName.setText(supplierName);
                editSupplierPhoneNumber.setText(supplierPhoneNumber);

            }
        } finally {
            cursor.close();
        }
        editDecrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(editQuantity.getText().toString());
                if (quantity > 0) {
                    quantity--;
                }
                editQuantity.setText(String.valueOf(quantity));
            }
        });

        editIncrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(editQuantity.getText().toString());
                if (quantity > -1) {
                    quantity++;
                }
                editQuantity.setText(String.valueOf(quantity));
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_menu_style, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.editing_item:
                setValues();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setValues() {
        ContentValues values = new ContentValues();

        String productName = editProductName.getText().toString();
        boolean checkProductName = !productName.isEmpty();
        if (checkProductName) {
            values.put(PRODUCT_NAME, productName);
        } else {
            editProductName.setError("required");
        }

        String price = editPrice.getText().toString();
        boolean checkPrice = !price.isEmpty();
        if (checkPrice) {
            values.put(PRICE, price);
        } else {
            editPrice.setError("required");
        }

        String quantity = editQuantity.getText().toString().trim();
        values.put(QUANTITY, quantity);

        String supplierName = editSupplierName.getText().toString();
        boolean checkSupplerName = !supplierName.isEmpty();
        if (checkSupplerName) {
            values.put(SUPPLIER_NAME, supplierName);
        } else {
            editSupplierName.setError("required");
        }

        String supplierPhoneNumber = editSupplierPhoneNumber.getText().toString();
        boolean checkSupplierPhoneNumber = !supplierPhoneNumber.isEmpty();
        if (checkSupplierPhoneNumber) {
            values.put(SUPPLIER_PHONE_NUMBER, supplierPhoneNumber);
        } else {
            editSupplierPhoneNumber.setError("required");
        }


        if (checkProductName && checkPrice && checkSupplerName && checkSupplierPhoneNumber) {

            getContentResolver().update(uri, values, null, null);
            editProductName.setText("");
            editPrice.setText("");
            editQuantity.setText(0 + "");
            editSupplierName.setText("");
            editSupplierPhoneNumber.setText("");
            Toast.makeText(getApplicationContext(), "the dat is updated", Toast.LENGTH_LONG).show();

            finish();
        }

    }
}
