package com_.example.mkwan.inventoryapp;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.widget.Toast;

import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.TABLE_NAME;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory._ID;

public class InventoryProvider extends android.content.ContentProvider {
    private InventoryDbHelper dbHelper;
    public static final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    public static final int INVENTORY = 100;
    public static final int INVENTORY_ID = 101;

    static {
        uriMatcher.addURI(InventoryContract.CONTENT_AUTHORITY, InventoryContract.PATH_INVENTORY, INVENTORY);
        uriMatcher.addURI(InventoryContract.CONTENT_AUTHORITY, InventoryContract.PATH_INVENTORY + "/#", INVENTORY_ID);
    }

    @Override
    public boolean onCreate() {
        dbHelper = new InventoryDbHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] strings, @Nullable String s, @Nullable String[] strings1, @Nullable String s1) {
        SQLiteDatabase sqLiteDatabase = dbHelper.getReadableDatabase();
        Cursor cursor;
        int match = uriMatcher.match(uri);
        switch (match) {
            case INVENTORY:
                cursor = sqLiteDatabase.query(TABLE_NAME, strings, s, strings1, null, null, s);
                break;
            case INVENTORY_ID:
                cursor = queryInventory(uri, strings, s, strings1, s1);
                break;
            default:
                throw new IllegalArgumentException("Can not query unknown URI " + uri);
        }
        return cursor;
    }

    private Cursor queryInventory(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor;
        selection = _ID + "=?";
        selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
        cursor = db.query(TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);

        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        int match = uriMatcher.match(uri);
        switch (match) {
            case INVENTORY:
                return insertInventory(uri, contentValues);
            default:
                throw new IllegalArgumentException("Cannot query unknown URI" + uri);
        }
    }

    private Uri insertInventory(Uri uri, ContentValues values) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long id = db.insert(TABLE_NAME, null, values);

        if (id == -1) {
            Toast.makeText(getContext(), "Failed to insert row for " + uri, Toast.LENGTH_SHORT).show();
            return null;
        }
        return ContentUris.withAppendedId(uri, id);
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String s, @Nullable String[] strings) {
        final int match = uriMatcher.match(uri);
        switch (match) {
            case INVENTORY:
                break;
            case INVENTORY_ID:
                return deleteInventory(uri, s, strings);
            default:
                throw new IllegalArgumentException("Deletion is not supported for " + uri);
        }
        return 0;
    }

    private int deleteInventory(Uri uri, String selection, String[] selectionArgs) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        selection = _ID + "=?";
        selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};

        return db.delete(TABLE_NAME, selection, selectionArgs);
    }


    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        final int match = uriMatcher.match(uri);
        switch (match) {
            case INVENTORY:
                break;
            case INVENTORY_ID:
                return updateInventoryId(uri, contentValues, s, strings);
            default:
                throw new IllegalArgumentException("Update is not supported for " + uri);
        }
        return 0;
    }

    private int updateInventoryId(Uri uri, ContentValues values, String selection, String[] selectionArgs) {

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        selection = _ID + "=?";
        selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};

        return db.update(TABLE_NAME, values, selection, selectionArgs);
    }

}
