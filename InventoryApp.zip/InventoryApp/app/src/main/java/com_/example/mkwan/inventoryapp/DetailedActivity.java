package com_.example.mkwan.inventoryapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import static android.provider.BaseColumns._ID;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.CONTENT_URI;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.PRICE;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.PRODUCT_IMAGE;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.PRODUCT_NAME;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.QUANTITY;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.SUPPLIER_NAME;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.SUPPLIER_PHONE_NUMBER;


public class DetailedActivity extends AppCompatActivity {

    TextView productNameTextView;
    TextView priceTextView;
    TextView quantityTextView;
    TextView supplierNameTextView;
    TextView supplierPhoneNameTextView;
    ImageView imageView;
    ImageView increaseImageView;
    ImageView decreaseImageView;
    Button orderButton;
    Uri uri;
    Button deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed);
        productNameTextView = findViewById(R.id.detailed_product_name_tv);
        priceTextView = findViewById(R.id.detailed_price_tv);
        quantityTextView = findViewById(R.id.detailed_quantity_tv);
        supplierNameTextView = findViewById(R.id.detailed_supplier_name_tv);
        supplierPhoneNameTextView = findViewById(R.id.detailed_supplier_phone_number_tv);
        imageView = findViewById(R.id.detailed_image_view);
        increaseImageView = findViewById(R.id.increase);
        decreaseImageView = findViewById(R.id.decrease);
        orderButton = findViewById(R.id.order_button);
        deleteButton = findViewById(R.id.delete_button);

        Intent intent = getIntent();
        String id = String.valueOf(intent.getStringExtra(_ID));
        uri = Uri.withAppendedPath(CONTENT_URI, id);


        String[] columns = {_ID,
                PRODUCT_NAME,
                PRICE,
                QUANTITY,
                SUPPLIER_NAME,
                SUPPLIER_PHONE_NUMBER,
                PRODUCT_IMAGE};
        Cursor cursor = getContentResolver().query(uri, columns, null, null, null);
        try {
            while (cursor.moveToNext()) {
                int productImageIndex = cursor.getColumnIndexOrThrow(PRODUCT_IMAGE);
                int productNameIndex = cursor.getColumnIndexOrThrow(PRODUCT_NAME);
                int priceIndex = cursor.getColumnIndexOrThrow(PRICE);
                final int quantityIndex = cursor.getColumnIndexOrThrow(QUANTITY);
                int supplierNameIndex = cursor.getColumnIndexOrThrow(SUPPLIER_NAME);
                int supplierPhoneNumberIndex = cursor.getColumnIndexOrThrow(SUPPLIER_PHONE_NUMBER);


                String currentProductImage = cursor.getString(productImageIndex);
                String currentProductName = cursor.getString(productNameIndex);
                int currentPrice = cursor.getInt(priceIndex);
                int currentQuantity = cursor.getInt(quantityIndex);
                String currentSupplierName = cursor.getString(supplierNameIndex);
                final String currentSupplierPhoneName = cursor.getString(supplierPhoneNumberIndex);
                productNameTextView.setText(currentProductName);
                imageView.setImageBitmap(StringToBitMap(currentProductImage));
                priceTextView.setText(String.valueOf(currentPrice));
                quantityTextView.setText(String.valueOf(currentQuantity));
                supplierNameTextView.setText(currentSupplierName);
                supplierPhoneNameTextView.setText(currentSupplierPhoneName);

                orderButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(Intent.ACTION_DIAL);
                        intent.setData(Uri.parse("tel:" + currentSupplierPhoneName));
                        startActivity(intent);
                    }
                });

                deleteButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(DetailedActivity.this);
                        View deleteView = LayoutInflater.from(DetailedActivity.this).inflate(R.layout.delete_dialog_layout, null);
                        builder.setView(deleteView);
                        final AlertDialog alertDialog = builder.create();
                        alertDialog.show();

                        Button yesBtn = deleteView.findViewById(R.id.yes_btn);
                        yesBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                getContentResolver().delete(uri, null, null);
                                finish();
                            }
                        });
                        Button noBtn = deleteView.findViewById(R.id.no_btn);
                        noBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                alertDialog.hide();
                            }
                        });
                    }
                });
            }
        } finally {
            cursor.close();
        }

        decreaseImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(quantityTextView.getText().toString());
                if (quantity > 0) {
                    quantity--;
                }
                quantityTextView.setText(quantity + "");
            }
        });

        increaseImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(quantityTextView.getText().toString());
                if (quantity > -1) {
                    quantity++;
                }
                quantityTextView.setText(quantity + "");
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.save_edit_detaile_menu_style, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.edit_item:
                setValues();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setValues() {
        ContentValues values = new ContentValues();

        String quantity = quantityTextView.getText().toString().trim();
        values.put(QUANTITY, quantity);
        getContentResolver().update(uri, values, null, null);
        finish();
    }


    public Bitmap StringToBitMap(String encodedString) {
        try {
            byte[] encodeByte = Base64.decode(encodedString, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch (Exception e) {
            e.getMessage();
            return null;
        }
    }


}
