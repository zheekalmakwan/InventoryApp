package com_.example.mkwan.inventoryapp;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.CONTENT_URI;

public class AddActivity extends AppCompatActivity {

    InventoryDbHelper inventoryDbHelper;
    EditText productNameEditText;
    EditText priceEditText;
    EditText quantityEditText;
    EditText supplierNameEditText;
    EditText supplierPhoneNumberEditText;
    private int GALLERY = 1;
    ImageView imageView;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        inventoryDbHelper = new InventoryDbHelper(this);
        productNameEditText = findViewById(R.id.product_name_et);
        priceEditText = findViewById(R.id.price_et);
        quantityEditText = findViewById(R.id.quantity_et);
        supplierNameEditText = findViewById(R.id.supplier_name_et);
        supplierPhoneNumberEditText = findViewById(R.id.supplier_phone_number_et);
        imageView = findViewById(R.id.image_view);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPictureDialog();
            }
        });
    }

    private void showPictureDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Pick a Picture");
        String[] pictureDialogItems = {
                "Select photo from gallery"};
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallary();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    public void choosePhotoFromGallary() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, GALLERY);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();
                try {

                    bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), contentURI);
                    imageView.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
            case R.id.add_item_success:
                ContentValues values = new ContentValues();
                if (bitmap != null) {
                    values.put(InventoryContract.Inventory.PRODUCT_IMAGE, BitMapToString(bitmap));
                } else {
                    Toast.makeText(this, "you must add an Image", Toast.LENGTH_LONG).show();
                }
                if (TextUtils.isEmpty(productNameEditText.getText())) {

                    productNameEditText.setError("Product name is required!");
                } else {
                    values.put(InventoryContract.Inventory.PRODUCT_NAME, productNameEditText.getText().toString());

                }


                if (TextUtils.isEmpty(priceEditText.getText())) {

                    priceEditText.setError("Price is required!");
                } else {
                    values.put(InventoryContract.Inventory.PRICE, priceEditText.getText().toString());
                }

                if (TextUtils.isEmpty(quantityEditText.getText())) {

                    quantityEditText.setError("Quantity is required!");
                } else {
                    values.put(InventoryContract.Inventory.QUANTITY, quantityEditText.getText().toString());
                }


                if (TextUtils.isEmpty(supplierNameEditText.getText())) {

                    supplierNameEditText.setError("SupplierName is required!");
                } else {
                    values.put(InventoryContract.Inventory.SUPPLIER_NAME, supplierNameEditText.getText().toString());
                }
                if (TextUtils.isEmpty(supplierPhoneNumberEditText.getText())) {

                    supplierPhoneNumberEditText.setError("SupplierPhoneNumber is required!");
                } else {
                    values.put(InventoryContract.Inventory.SUPPLIER_PHONE_NUMBER, supplierPhoneNumberEditText.getText().toString());
                }

                Uri newRowId = getContentResolver().insert(CONTENT_URI, values);

                if(newRowId!=null) {
//                if (this.shouldSubmit())
                   finish();
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private boolean shouldSubmit() {
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_menu_style, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public String BitMapToString(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();
        String temp = Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }
}
