package com_.example.mkwan.inventoryapp;

import android.net.Uri;
import android.provider.BaseColumns;

public final class InventoryContract {

    public static final String CONTENT_AUTHORITY = "com_.example.mkwan.inventoryapp";
    public static final Uri CONTENT_BASE_ = Uri.parse("content://" + CONTENT_AUTHORITY);
    public static final String PATH_INVENTORY = "Inventory";//Inventory is the table name

    public static class Inventory implements BaseColumns {
        public static final String TABLE_NAME = "Inventory";
        public static final String PRODUCT_NAME = "ProductName";
        public static final String PRICE = "Price";
        public static final String QUANTITY = "Quantity";
        public static final String SUPPLIER_NAME = "SupplierName";
        public static final String SUPPLIER_PHONE_NUMBER = "SupplierPhoneNumber";
        public static final String PRODUCT_IMAGE = "ProductImage";
        public static final Uri CONTENT_URI = Uri.withAppendedPath(CONTENT_BASE_, PATH_INVENTORY);
    }
}
