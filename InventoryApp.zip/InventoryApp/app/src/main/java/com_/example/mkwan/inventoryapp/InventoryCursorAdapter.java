package com_.example.mkwan.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.CONTENT_URI;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory.QUANTITY;
import static com_.example.mkwan.inventoryapp.InventoryContract.Inventory._ID;

public class InventoryCursorAdapter extends CursorAdapter {
    public InventoryCursorAdapter(Context context, Cursor c) {
        super(context, c, 0);
    }


    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        return LayoutInflater.from(context).inflate(R.layout.list_view_item_style, viewGroup, false);
    }

    @Override
    public void bindView(View view, final Context context, final Cursor cursor) {

        TextView productNameTv = view.findViewById(R.id.product_name_tv);
        TextView priceTv = view.findViewById(R.id.price_tv);
        final TextView quantityTv = view.findViewById(R.id.quantity_tv);
        ImageView productImageIv = view.findViewById(R.id.product_iv);
        Button saleButton = view.findViewById(R.id.sale_button);
        Button editButton = view.findViewById(R.id.edit_button);

        String productName = cursor.getString(cursor.getColumnIndex(InventoryContract.Inventory.PRODUCT_NAME));
        int price = cursor.getInt(cursor.getColumnIndex(InventoryContract.Inventory.PRICE));
        final int id = cursor.getInt(cursor.getColumnIndex(_ID));
        final int quantity = cursor.getInt(cursor.getColumnIndex(QUANTITY));
        String productImage = cursor.getString(cursor.getColumnIndex(InventoryContract.Inventory.PRODUCT_IMAGE));
        productNameTv.setText(productName);
        priceTv.setText(String.valueOf(price));
        quantityTv.setText(String.valueOf(quantity));
        productImageIv.setImageBitmap(StringToBitMap(productImage));

        saleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues values = new ContentValues();
                int quantitySale = Integer.parseInt(quantityTv.getText().toString().trim());
                if (quantitySale > 0) {
                    quantitySale--;
                    values.put(QUANTITY, quantitySale);
                    Uri uri = Uri.withAppendedPath(CONTENT_URI, String.valueOf(id));
                    view.getContext().getContentResolver().update(uri, values, null, null);
                    quantityTv.setText(quantitySale + "");
                }
            }
        });

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), EditActivity.class);

                intent.putExtra(_ID, String.valueOf(id));
                view.getContext().startActivity(intent);
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetailedActivity.class);

                intent.putExtra(_ID, String.valueOf(id));
                v.getContext().startActivity(intent);
            }
        });
    }

    public static Bitmap StringToBitMap(String encodedString) {
        try {
            byte[] encodeByte = Base64.decode(encodedString, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch (Exception e) {
            e.getMessage();
            return null;
        }
    }
}
